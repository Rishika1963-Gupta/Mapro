document.getElementById("back-button").addEventListener("click", function() {
    window.location.href = "HomePage.html"
})